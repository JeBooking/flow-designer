@echo off
setlocal
cd /d "%~dp0"
node scripts/start-app.mjs --production
pause
