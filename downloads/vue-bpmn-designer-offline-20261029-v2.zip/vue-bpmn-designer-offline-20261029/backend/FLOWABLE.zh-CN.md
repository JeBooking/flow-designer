# Flowable 外部 Python 诊断

## 当前是/否执行约定

排查支持是和否两组出口，每组可有任意条连线，也可以缺省，使用 `flowable:diagnosisBranch` 保存。
没有匹配后续节点时，在 `diagnosticFailures` 中记录该思路失败。
流程属性 `flowable:diagnosisMode` 选择 `parallel`（默认）或 `serial`。
并行模式同步触发同组思路，无优先级；失败只结束当前思路，不重新触发兄弟思路。汇合按每次到达继续，无需强制聚合网关。
串行模式使用持久化队列，按 `flowable:diagnosisOrder` 升序、未指定时按 XML 顺序依次排查。
失败后尝试下一个待执行思路，全部耗尽且未成功时 `diagnosticStatus=failed`。
成功后暂停剩余思路（`diagnosticStatus=paused`）；界面可选择结束或继续，复核接口
使用 `mode=success`，提交 `action=confirm` 和 `next=finish` 或 `continue`。
继续操作恢复保留的队列，不重放已经完成的路径。有条件的判断应放在排查节点；结论只记录文本时无需绑定 Python，
会自动进入后继，不会仅凭结论产生人工等待。
导出的离线 Python 遵循相同规则，通过 `run(..., resume=state, success_action='continue'|'finish')` 恢复暂停状态。

worker 使用 `inspect.signature` 识别参数：兼容旧映射、匹配同名流程变量、上游结果中唯一的同名字段、
再使用默认值；缺失或歧义会提示具体参数。支持位置专用参数、异步接口、无输入及无返回值动作。
排查返回 `True`/`False`、`yes`/`no` 或 `{"next":"yes"}`；旧连线 ID 选择该线所属的整个分组。
节点面板无需填写参数语言。

没有分组的排查连线会被拒绝，不根据排列顺序猜测。

浏览器编辑自定义诊断节点，导出器将它们转换成标准服务任务、排他网关和结束事件。
Flowable 7.1.0 负责调度；官方 `flowable.external-worker-client==1.0.2` 负责领取任务和提交结果。
`flowable_worker.py` 只负责调用绑定的 Python 函数，不实现自己的流程引擎。

## 首次准备

需要 JDK 17 或更高版本、Python 3.9+ 和项目原有的 Node.js/pnpm 环境；17 包括 17.0.12 等更新版本。
首次没有引擎 JAR 时还需在 PATH 中提供 Maven 3.8.8+。在仓库根目录安装前端依赖：

```powershell
pnpm install
```

`pnpm dev` 或 `pnpm start` 检测到缺少本地引擎 JAR 时，会自动执行 Maven 构建，
下载所需 Java 依赖并生成 `flowable-runtime/target/diagnostic-flowable-1.0.0.jar`。
构建过程显示在终端，日志为 `backend/.local/logs/flowable-build.log`。
编译目标为 Java 17，使用较新 JDK 构建时也保持 Java 17 兼容。
构建失败或中断后重新启动即可重试；已有 JAR 且构建配置未更新时无需 Maven，也不会每次重新构建。
更新 `pom.xml` 后会自动清理旧编译产物并重新构建，避免复用旧的 Java 21 字节码。
配置外部 `FLOWABLE_URL` 或复用已通过检查的引擎时不构建本地引擎。
缺少工具或版本不符合时，会明确提示检查 PATH/JAVA_HOME；启动器不安装 JDK/Maven 本身。

项目配置关闭了 pnpm 启动前的隐式依赖安装，首次准备或前端依赖变更后运行 `pnpm install`。
`pnpm-workspace.yaml` 中明确允许所列前端依赖的安装脚本，不使用未填写的占位值。

首次运行 `pnpm dev` 或 `pnpm start` 时，启动器自动创建 `backend/.local/venv`，
并按 `backend/requirements-flowable.txt` 安装平台依赖。后续启动检查版本、导入和依赖完整性，
已就绪时直接复用，不重复安装。安装需要访问 Python 软件源；支持已有代理和 `PIP_INDEX_URL` 配置。
失败时终端显示错误，完整记录在 `backend/.local/logs/python-*.log`，解决原因后重新启动即可。

平台仍需 Python 3.9+，当前 Flowable 客户端不能直接运行于 Python 3.7。
创建环境时默认在 PATH 中查找 Python；Windows 也尝试 Python launcher。
可先设置 `$env:PYTHON = 'C:\Path\To\python.exe'` 指定创建环境的基础解释器；
已有可用的项目环境优先复用。此设置不会向基础解释器中安装依赖。
迁移后失效的项目环境会备份为 `backend/.local/venv.backup-<时间戳>`，再自动重建。
不要把旧机器的虚拟环境当作可移植运行环境；业务工程的路径与解释器也须适配新机器。

业务依赖仍安装在该工程登记的解释器环境，启动器不自动安装业务依赖、下载 Python/Java、
安装前端依赖。复用已通过检查的 Python 后端时，跳过本地 Python 环境准备。
Java 引擎代码升级后需重新构建 jar，再重启自有服务。

本地引擎默认监听 `127.0.0.1:8080`，认证为 `diagnostic / local-demo`，H2 数据库保存在
`flowable-runtime/data/`。通过 `FLOWABLE_USER`、`FLOWABLE_PASSWORD` 配置账号密码，
Python 代理和 worker 使用相同设置。需要对本机以外提供服务时，应配置访问控制与合适的数据库。

## 日常执行

在仓库根目录运行：

```powershell
pnpm dev
```

启动器统一启动前端、Python 后端和本地 Java 引擎。打开终端打印的编辑器地址，默认是
`http://127.0.0.1:5173/vue-bpmn-designer/`。已有服务通过身份和健康检查后可复用，
复用后端还必须报告相同的 Flowable URL。显式配置 `FLOWABLE_URL` 时只连接指定外部引擎，
不会另外启动本地 Java 引擎；默认地址为 `http://127.0.0.1:8080`。

生产运行先用 `pnpm build` 准备 `dist/`，再执行 `pnpm start`；生产启动要求已有构建产物。
`pnpm dev:frontend` 只启动 Vite，供已单独管理其他服务的场景使用。

1. 在“Python 项目”登记已有业务工程，在当前流程图节点上选择对应接口。
2. 打开“诊断执行”，填写类/工厂所需的初始化输入；可选输入留空保留 Python 默认值。
   额外启动数据可添加名称/值行。高级初始变量 JSON 默认折叠，开启后替代表单，默认 `{}`。
   普通方法参数继续从上游结果自动匹配。
3. 点击“开始执行”。后端编译当前图，经 `execution_manager.py` 准备或复用对应 worker，
   再部署并启动实例。浏览器执行不需要先导出执行包或手工启动 worker。
4. 执行结果自动更新，真实执行、等待和失败节点会在画布高亮。结果卡片展示对象字段，数组以表格呈现；
   返回 `chartSvg` 时显示图表。原始执行详情默认折叠，按需展开；失败详情可查看可用的原始 Python traceback。
5. 人工待办自动从节点展开浮动窗口，曲线连接节点，各自保留输入和错误，完成后收回。
   可拖动标题或用方向键移动（Shift 加大步长），支持自动排布与恢复自动定位。收起不代表完成，
   点击节点橙色待处理按钮可重开；窄屏使用待办卡片轨道。窗口展示完整说明、参考与判断依据。
   点击节点的绿色完成勾可查看历史记录，
   包括每轮起止时间和耗时。新执行逐次保存函数实际输入（含默认值）、实例初始化输入（配置工厂时）、
   返回的依据／结果、部署时的说明和参考文件、所选分支及错误。人工记录保存当时可用上下文、依据、
   参考和选择；该上下文与函数实际参数分别标记。重跑保留此前记录。旧实例或缺失字段显示“未记录”，
   不会补造快照。

Python 脚本未返回的局部中间变量无法自动获取。需要保留的采集值、参考值和判断依据，
应通过返回结构或 `HumanDecisionRequest.data` 提供；人工处理示例中的 `voltage`、`threshold`、
`unit` 就是这样提供的依据。

关闭抽屉后继续监控当前实例并更新画布提示，直到流程结束；结束后保留已完成节点的提示。
修改画布或导入流程图后，隐藏旧实例的画布提示。
浏览器刷新或 Modeler 重建不会恢复当前实例监控，请保留实例 ID 供排查。
死信失败后可确认“重新执行当前流程”：这会创建新实例，不取消旧实例，机台动作可能重复执行。

启动器及服务日志位于 `backend/.local/logs/`，托管 worker 日志位于
`backend/.local/executions/<hash>/<uuid>.log`。退出启动器只停止它启动的服务及其托管 worker，
复用服务和外部服务继续运行。停止服务不会撤销设备动作，重新启动也不会恢复原生会话。

## 上升复核与回退重查

编译后的执行流程到达“上升”时不会立即结束，而是进入 Flowable 人工复核任务。
画布中的“上升”仍然是最终节点；编译器在引擎定义里插入等待复核步骤。
只有点击“确认上升并结束”才到达真正的结束事件。到达“问题解决”时，串行模式若仍有待执行思路，
会暂停等待选择结束或继续；并行模式成功不取消其他已启动支路。
Java 引擎升级后需重新构建 jar、重启服务，再从当前图开始新执行；已有旧版本实例不改变行为。

1. 自动监控显示等待人工复核，并在复核卡片标明上升节点后，选择此前实际执行过的节点，填写回退原因。
2. 可选修改业务输入变量，真实工程通常在重新调用采集接口时获得新数据。
3. 点击“回退重查”。Flowable 在同一实例中返回所选节点，Python 重新执行该节点及后续路径。
4. 如果重查后仍上升，可以继续复核；如果确认无法恢复，点击“确认上升并结束”。

回退不是撤销：不会恢复机台状态，也不会删除原诊断路径。后续机台动作可能再次执行。
输入相同、代码相同的确定性算法可能给出相同判断；回退本身不会自动纠正算法。

回退会清理目标及需要重算的下游结果和路由变量，并保留有效的上游结果。
旧结果、输入修改前后的值、回退原因和时间保存为 `diagnosticReviews` 流程变量，
可在“执行详情”中查看；Flowable 活动历史保留每次经过节点和复核的记录。
清理、记录与状态变更在同一事务内执行，避免 worker 读取半更新状态。
不能通过输入变量覆盖节点结果、路由变量或复核记录，也不能使用过期的复核页面提交操作。

复核接口 `/diagnosis-api/instances/{id}/review` 由同一 Java 服务提供，并使用相同认证。
`GET /review/tasks` 返回按创建时间、任务 ID 排序的全部待办 `{tasks: [...]}`；`GET /review`
保留首条兼容。历史接口新增 `pendingReviews`，同时保留首条 `review`。每个任务包含可回退节点
和 `canRecheck`。并行多个待办时禁用回退，避免清理共享结果影响其他任务，请先处理其余人工任务。
`POST /review` 的 `action` 为 `recheck` 或 `confirm`，
必须携带当前 `taskId`。回退还需要 `targetNodeId`、`reason`，可选 `variables`。
已经确认结束的实例不再允许回退。

## 任意人工判断节点的回退

在排查节点的“执行与人工判断”中启用“人工判断／确认”。
不配置 Python 接口时直接等待人工；配置接口时先执行采集、绘图或动作，再等待人工选择。
多后继节点按出线名称列出选项，必须明确选择；单后继节点提供“确认并继续”。
所有这些等待入口以及上升复核均提供回退，可选择此前实际执行过的排查、结论或动作节点。
当前节点和未执行节点不能作为回退目标；首个节点会提示暂无可回退节点。
回退到 manual 动作仍等待人工，即使保留绑定也不调用 Python。回退到有绑定的排查，或 automatic／confirm
动作，会重新执行接口；confirm 执行后再次等待核验。
本次不包含运行中自动节点的暂停介入；“问题解决”遵循前述串行成功暂停与并行支路规则。

复核返回 `mode`、完整说明、参考、依据、业务上下文 `inputs` 和 `selectionMode: single`。
`options` 保留“是／否”组 ID 和名称，各组附带 `paths: [{id: 连线ID, name: 目标名称, target: 节点ID}]`。
先单选“是／否”组，再勾选组内路径，默认全选，不跨组混选。POST `action: confirm` 传
`next: yes|no`，可选 `selectedFlowIds`；未传时选择该组全部路径，重复、跨组和有出口的空选都会拒绝。
没有后继的组仍按原语义记录思路失败。路径子集需要重新编译部署，自动判断仍执行整个匹配组。
Python 的 `next` 在人工模式中只是建议，可以省略；实际路由由人工选择决定。
确认后节点结果中的 `next` 更新为实际选择并带有 `humanConfirmed: true`，原始结果保存在复核记录。
对象结果的其他字段保持不变；非对象结果包装在 `data` 中，纯人工节点生成确认结果。
结果和审计记录同时保留 `selectedFlowIds`。提交严格核对当前实例的活跃任务，过期或并发冲突返回 HTTP 409。
新增配置保存为 `flowable:humanDecision`，支持撤销、重做和 XML 导入导出。
升级后重启相关服务，并从当前图开始新执行；已部署实例保持原行为。
编译后的配置存储在 `flowable:diagnosticExecution` 扩展元素，避免流程说明 2000 字符限制。

## 接入自己的工程

先在“Python 项目”登记已有目录、可导入模块、解释器及可选工厂。状态型工程最直接的入口是
`Device` 等现有类：公开绑定方法成为接口，`self` 不作为用户输入。登记类只检查签名，不创建实例；
实际会话创建时按同名启动变量或默认值传入构造参数。工厂函数有返回类注解时同样免调用发现；
无注解工厂会用默认值临时创建对象，有必填参数须补返回类注解。工厂留空兼容模块函数和 `__all__`。

业务对象入口只在顶部“Python 项目”接入时配置。在非最终节点选择已接入工程和方法/函数即可，
平台自动带入入口绑定，并继续兼容旧 XML 和 JSON 中的配置。签名自动匹配启动变量、按节点 ID 保存的完整原始结果、
唯一的字典同名字段，并保留默认值、位置专用参数和 `async def`；无需填写参数表达式。
旧映射仍兼容 `$Inspect.data`、`$`（全部变量）、字典/数组路径及 `$$device`（普通字符串 `$device`）。
动作允许返回 `None`，排查应返回明确是/否：`True`/`False`、`yes`/`no` 或含 `next` 的字典。
旧出口连线 ID 选择其所属整个分组；不以任意对象的真假性推测分支。最终节点不绑定业务逻辑。

托管 worker 使用已准备的官方客户端环境。默认读取 `backend/.local/projects.json`，按模块/工厂选登记，
业务子进程使用登记解释器及工程工作目录。业务依赖安装在实际执行该工程的解释器环境。
手工 CLI 参数见下方可选运维说明。

同一流程访问同一工程时共享一个常驻隔离 Python 子进程，工厂实例只创建一次，普通函数也保留模块
全局状态；不同流程完全隔离。原始结果在 Python 内按节点 ID 保存，可为任意 Python 对象。
Flowable 仅保存可 JSON 化的展示投影，需要时带 `native`、`pythonType`、`representation` 信息；
`repr` 展示不会当成原对象传给后续方法。原生引用不能跨工程子进程共享。同一实例上的并行方法须由
业务工程管理线程安全。分支调度、人工等待及历史仍由 Flowable 负责，没有新增另一套流程引擎。

接口调试的连续调用共享会话，“重置会话”重新开始；真实流程的回退则在当前实例上
重跑方法，不回滚内部状态。worker 观察到流程结束后释放会话，失败会话保留供检查。
没有自动检查点：worker/子进程重启会丢失会话，旧流程继续时明确报会话丢失，不会静默重建实例。
历史及展示投影不能还原原始对象。离线骨架仍按原来的补业务/人工兜底规则运行，不自动执行图上 binding。

同一 Flowable 服务的相同执行包/主题只启动一个 worker 协调器，其内部通过隔离子进程同时处理
多次排查。本机单例租约会明确拒绝重复订阅；该锁不能跨机器，因此不同机器间也须保持单协调器。
兼容普通无状态函数不代表多个竞争 worker 可以共享原生对象或安全水平扩容。

Python 任务失败后，执行结果自动更新，展开失败详情可查看原始 Python traceback；
worker 日志可补充上下文。

工作主题默认使用节点 ID，导出时加入流程 ID 和执行定义摘要，避免不同图的同名任务混用函数。
移动节点、修改说明文字或 XML/参数 JSON 重新格式化不会改变主题。
同一张图内主题不得重复。连线、绑定或参数修改后，从当前图开始新执行，后端会准备对应 worker；
旧实例仍需原 worker 和原生会话。
原图中的条件表达式和默认分支会在导出时明确拒绝；自动模式使用 Python 的 `next`，人工模式使用人工选择。
不要同时让配置不同的 worker 订阅同一组主题。

当前执行导出支持一个顶层流程、一个普通开始事件和这些诊断节点；子流程、并行节点、复杂事件等会明确拒绝。
排查须绑定接口或启用人工判断；动作按动作模式执行，纯文本结论无需绑定接口，均需满足内容、连接和终点规则。
外部任务失败、超时重领可能造成重复调用，真实机台操作函数须按业务需要保证幂等。
桌面绘图函数若要求主线程或交互桌面，应在业务入口中启动独立桌面进程；官方客户端回调运行在线程中。

## 动作执行与人工核验

排查动作（`investigationAction`）和处置措施（`remediation`）使用 `flowable:actionMode`
保存模式，支持撤销、重做和 XML 导入导出：

| 模式 | Python 执行 | 继续条件 |
| --- | --- | --- |
| `automatic` | 调用绑定接口 | 成功后自动继续 |
| `manual` | 不调用 Python，即使保存了旧绑定 | 等待人工 OK |
| `confirm` | 复核前调用一次接口 | 等待人工核验后 OK |

未保存模式时，有接口默认自动，无接口默认人工。人工动作无需登记 Python 工程；纯人工模拟演练
可整体导入 [`manual_action_project`](examples/manual_action_project/README.zh-CN.md) 目录。
Cooling 的 `RestartFan`、`CleanFilter` 明确使用 confirm，报告节点为 automatic。
默认 fan 场景会等待动作核验；串行 filter 先核验动作，报告到问题解决后，另一次成功复核才提供结束／继续。

动作复核使用 `mode=action`。向 `POST /diagnosis-api/instances/{id}/review` 提交
`action=confirm`、当前 `taskId` 和 `next=ok` 或 `next=not_ok`。只有 OK 完成任务并进入后继。
不OK 会记录 `actionResult` 和当时可用上下文，同一个任务仍为待处理，不自动重跑 Python 接口，
也不到问题解决。实际重新完成动作后可选 OK，或回退到符合条件的已执行节点。
动作待办响应包含 `actionMode`、`lastActionResult`，每次提交保留在 `diagnosticReviews` 中。
POST 对不OK 返回 `pending=true`，对已确认的 OK 返回 `pending=false`，并附带提交的 `actionResult`。
普通 Python 异常仍按任务失败处理并保留原始 traceback，不会转换为不OK。
回退可能重新执行动作，不会撤销设备状态。

## 判断组件自动转人工

`backend/diagnostic_components.py` 为排查节点提供可复用的 Python 判断组件。Flowable 接收等待请求、
保存状态和继续执行。排查无需开启“人工判断／确认”也能请求人工判断；该开关用于额外要求
人工复核自动结果。动作使用 `flowable:actionMode` 及上述独立的动作复核约定。

```python
from diagnostic_components import DecisionComponent, decision

judge = DecisionComponent()

def diagnose(reading):
    return judge.run(reading, instructions='查看曲线，选择符合现场情况的后继')

@decision(instructions='查看曲线，选择符合现场情况的后继')
def diagnose_with_decorator(data):
    raise NotImplementedError('待实现业务判断')
```

基类未覆盖 `decide(self, data)`，或被装饰函数明确抛出 `NotImplementedError`，都会返回 `HumanDecisionRequest`。补齐实现后正常返回 JSON，多分支包含 `{"next": "连线ID", ...}`，即自动继续。`pass` / 返回 `None` 不表示未实现；其他异常仍是任务失败。同步、异步函数均支持。装饰器用于普通函数，其第一个参数或 `data` 关键字参数作为判断依据；类方法建议使用基类。

接口应直接返回请求对象，不要自行转成 JSON。请求携带数据与可选说明，不阻塞 worker 等待人工输入。说明留空时沿用流程图中的诊断方法；参考图和后继选项仍来自流程图。可选 `options` 必须与全部后继连线 ID 一致。界面展示依据数据和图表，允许选择分支或回退；回退同时清理失效的请求。

worker 已提供该模块的导入路径，业务工程正常导入即可；独立运行业务工程时应将 `backend` 加入 Python 导入路径。导出的代码骨架包含同一模块，由命令行界面收集人工选择。

组件升级后使用更新的服务和 worker 开始新执行；已有实例仍需原版本 worker 和原生会话。

## 可选的手工 worker 运维

在托管浏览器流程以外的运维场景，可以给 worker 显式传入已准备的绑定清单。
不要为托管 worker 已占用的主题另开竞争 worker：

```powershell
backend/.local/venv/Scripts/python.exe backend/flowable_worker.py C:/exports/bindings.json
```

`--registry PATH` 指定登记文件，可重复的 `--project PATH` 为未登记旧模块指定备用目录，
此时使用 worker 自身解释器。手工启动同样受前述单协调器、原生会话与重启边界限制，
不是“开始执行”的前置步骤。
